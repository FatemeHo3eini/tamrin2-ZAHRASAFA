#include<iostream>
#include<conio.h>
using namespace std;

int main()
{
	int time, hour, min, sec;
	cout << "Enter time : ";
	cin >> time;
	hour = time / 3600;
	time %= 3600;
	min = time / 60;
	sec = time % 60;
	cout << hour << " : " << min << " : " << sec << endl;
	
	getch();
    return 0;
}
