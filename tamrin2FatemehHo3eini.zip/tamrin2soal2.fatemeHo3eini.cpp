#include<iostream>
#include<conio.h>
using namespace std;

int main()
{
	int hour, min, sec, time;
	cout << "Enter (hour min sec) : ";
	cin >> hour >> min >> sec;
	time = hour * 3600 + min * 60 + sec;
	cout << time << endl;
	
	getch();
    return 0;
}
