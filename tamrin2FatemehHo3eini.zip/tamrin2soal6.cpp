#include<iostream>
#include<conio.h>
using namespace std;

int main()
{
	int x = 1, y = 1, z, n;
	cout << "Enter number of Fionachi series : ";
	cin >> n;
	for (int i = 0; i<n; i++) {
		if (i > 1) {
			z = x + y;
			cout << z << " , ";
			x = y;
			y = z;
		}
		else
			cout << "1 , ";
	}
	
	getch();
    return 0;
}
