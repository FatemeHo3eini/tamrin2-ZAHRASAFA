#include<iostream>
#include<conio.h>
#include<time.h>
using namespace std;

int main()
{
	int dice;
	srand(time(0));
	while (true) {
		dice = rand() % 6 + 1;
		cout << "dice = " << dice << endl;
		if (dice == 6)
			cout << "you win." << endl;
		else
			break;
	}
	
	getch();
    return 0;
}
