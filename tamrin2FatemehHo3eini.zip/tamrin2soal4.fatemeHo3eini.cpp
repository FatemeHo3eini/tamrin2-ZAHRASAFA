#include<iostream>
#include<conio.h>
using namespace std;

int main()
{
	float avg, sum = 0, score[70], max, min;
	int number_student;
	cout << "Enter number of student: ";
	cin >> number_student;
	for (int i = 0; i<number_student; i++) {
		cout << "Enter score: ";
		cin >> score[i];
	}
	max = score[0];
	min = score[0];
	for (int i = 0; i<number_student; i++) {
		if (score[i] > max)
			max = score[i];
		if (score[i] < min)
			min = score[i];
		sum += score[i];
	}
	avg = sum / number_student;
	cout << " avg : " << avg << "\n min : " << min << "\n max : " << max << endl;
	
	getch();
    return 0;
}
