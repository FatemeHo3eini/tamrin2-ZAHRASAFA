#include<iostream>
#include<conio.h>
using namespace std;

int main()
{
	char str[5], exit[5] = "exit";
	int sum = 0, num;

	while (1) {
		cout << "add ra vared konid : ";
		cin >> num;
		sum += num;
		cout << "Enter (exit) for Exit : ";
		cin >> str;
		int flag = 1;
		for (int i = 0; str[i] != NULL; i++)
			if (str[i] != exit[i])
				flag = 0;
		if (flag)
			break;
	}
	cout << "sum = " << sum << endl;
	getch();
    return 0;
}
